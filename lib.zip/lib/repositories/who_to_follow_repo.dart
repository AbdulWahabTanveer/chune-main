abstract class WhoToFollowRepository {

}

class WhoToFollowRepositoryImpl extends WhoToFollowRepository {}

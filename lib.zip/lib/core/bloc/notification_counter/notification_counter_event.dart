part of 'notification_counter_bloc.dart';

class NotificationCounterEvent {
  final int count;

  const NotificationCounterEvent(this.count);
}

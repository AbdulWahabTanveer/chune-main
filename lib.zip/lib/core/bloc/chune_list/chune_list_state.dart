part of 'chune_list_bloc.dart';

abstract class ChuneListState extends Equatable {
  const ChuneListState();
}

class ChuneListInitial extends ChuneListState {
  @override
  List<Object> get props => [];
}

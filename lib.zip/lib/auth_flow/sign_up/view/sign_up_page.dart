import 'package:authentication_repository/authentication_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';

import '../sign_up.dart';

class SignUpPage extends StatelessWidget {
  const SignUpPage();

  static Route<void> route() {
    return MaterialPageRoute<void>(builder: (_) => const SignUpPage());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(title: const Text('Sign Up')),
      body: BlocProvider<SignUpCubit>(
        create: (_) => SignUpCubit(GetIt.I.get<AuthenticationRepository>()),
        child: const SignUpForm(),
      ),
    );
  }
}

part of 'chune_list_bloc.dart';

abstract class ChuneListEvent extends Equatable {
  const ChuneListEvent();
}

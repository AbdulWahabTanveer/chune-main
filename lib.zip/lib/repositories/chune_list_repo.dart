abstract class ChuneListRepository {

}

class ChuneListRepositoryImpl extends ChuneListRepository {}
